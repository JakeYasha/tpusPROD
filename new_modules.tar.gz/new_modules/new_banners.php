<?

class nBanners {

    public function get_banners(){
        echo '<!--YES BANNERS!-->';
    }

}






?>