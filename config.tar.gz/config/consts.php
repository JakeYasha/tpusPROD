<?php

define('APP_SPHINX_CONNECTION_PORT', 9306);

const SPHINX_MAX_INT = 50000;
const SPHINX_MAX_MATCHES_FULL = 1000000;
const YANDEX_METRIKA_TOKEN = 'AQAAAAAF2rIUAAAZQdQwcB0cHUmDt_qrpUhtQn8';
const YANDEX_METRIKA_COUNTER = '1383369';
const EMPTY_IMAGE_FILEID_STUB = 2664;

const KOLVO_STAT_ADD = 4;

const SPHINX_PRICE_INDEX = 'tovaryplus_rt_price_index';
const SPHINX_PRICE_DRAFT_INDEX = 'tovaryplus_rt_price_index_draft';
const SPHINX_FIRM_INDEX = 'tovaryplus_rt_firm_index';
const SPHINX_BANNER_INDEX = 'tovaryplus_rt_banner_index';
const SPHINX_PRICE_BRAND_INDEX = 'tovaryplus_rt_price_brand_index';
const SPHINX_FIRM_CATALOG_INDEX = 'tovaryplus_rt_firm_catalog_index';
const SPHINX_PRICE_SUGGEST_INDEX = 'tovaryplus_rt_price_suggest_index';
const SPHINX_PRICE_CATALOG_INDEX = 'tovaryplus_rt_price_catalog_index';

const APP_CATALOG_MODE_THRESHOLD = 10000;