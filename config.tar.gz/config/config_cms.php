<?php

define('APP_IS_DEV_MODE', true);
define('APP_SUB_SYSTEM_NAME', 'CMS');
define('CMS_LINK_PREFIX', 'cms');
define('CMS_VERSION_URL', '4-2');

require_once rtrim(dirname(__FILE__), '/') . '/config.php';
require_once rtrim(dirname(__FILE__), '/') . '/autoload.php';
require_once rtrim(dirname(__FILE__), '/') . '/special_consts.php';
require_once rtrim(dirname(__FILE__), '/') . '/consts.php';

