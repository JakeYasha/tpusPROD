<?php

return [
	'default' => [
		'connection_string' => 'mysql:host=localhost;dbname=tovaryplus_new;charset=utf8',
		'scheme' => 'mysql',
		'use_password' => true,
		'user_login' => 'root',
		'user_password' => 'XaquRmC3mWksnAA6vDWX'
	],
	'old' => [
		'connection_string' => 'mysql:host=localhost;dbname=tovaryplus_dev;charset=utf8',
		'scheme' => 'mysql',
		'use_password' => true,
		'user_login' => 'root',
		'user_password' => 'XaquRmC3mWksnAA6vDWX'
	],
	'727373' => [
		'connection_string' => 'mysql:host=127.0.0.1;dbname=727373;charset=utf8',
		'scheme' => 'mysql',
		'use_password' => true,
		'user_login' => 'root',
		'user_password' => 'XaquRmC3mWksnAA6vDWX'
	],
	'727373_dev' => [
		'connection_string' => 'mysql:host=127.0.0.1;dbname=727373_dev;charset=utf8',
		'scheme' => 'mysql',
		'use_password' => true,
		'user_login' => 'root',
		'user_password' => 'XaquRmC3mWksnAA6vDWX'
	],
];

