<?php

namespace App\Model\DraftFirm;

class CmsForm extends \Sky4\Model\Form {

	public function controls() {
		return [
		];
	}

}
