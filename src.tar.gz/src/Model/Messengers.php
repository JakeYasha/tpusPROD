<?php

namespace App\Model;
class Messengers extends \Sky4\Model\Composite {

}
