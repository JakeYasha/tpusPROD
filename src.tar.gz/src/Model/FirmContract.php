<?php

namespace App\Model;

class FirmContract extends \Sky4\Model\Composite {

	use Component\IdTrait,
	 Component\NameTrait,
	 Component\TimestampIntervalTrait,
	 Component\IdFirmTrait;
}
