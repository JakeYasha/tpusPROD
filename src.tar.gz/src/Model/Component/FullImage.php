<?php

namespace App\Model\Component;

class FullImage extends \App\Model\Component\Image {

	protected $field_name = 'full_image', $label = 'Изображение (рекомендованный размер 500*416)';

}
