<?php
// на 2024 год - не актуально
// ini_set('memory_limit', '4G');
// ini_set('max_execution_time', -1);
// require_once rtrim(__DIR__, '/').'/../../../config/config_app.php';
// \Sky4\App::init();
// ini_set("log_errors", 1);
// ini_set("error_log", '/var/www/sites/logs/tovaryplus.ru_yml_daemon.log');

// while (1) {
// 	$yml_action = new \App\Action\Crontab\YmlParse();
// 	$yml_action->execute();
// 	sleep(10);
// }