#!/bin/bash

/usr/local/php-fpm/bin/php /var/www/sites/tovaryplus.ru/src/Cron/php/minutely.php
